package com.example.sudhir.finder;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
public class mainActivity extends ActionBarActivity {

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ImageButton p = (ImageButton)findViewById(R.id.parking);
        ImageButton q = (ImageButton)findViewById(R.id.fuel);
        p.setOnClickListener(new View.OnClickListener() {
                                 @Override
                                 public void onClick(View v) {
                                     Intent i=new Intent(mainActivity.this, parking.class);
                                     EditText et1=(EditText)findViewById(R.id.pintext);
                                     i.putExtra(et1.getText().toString(),"PIN");
                                     startActivity(i);
                                 }
                             });
        q.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(mainActivity.this, fuel.class));
            }
        });
    }
}
