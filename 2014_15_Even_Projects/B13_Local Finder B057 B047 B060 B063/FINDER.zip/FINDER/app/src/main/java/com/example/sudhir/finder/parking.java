package com.example.sudhir.finder;

import android.content.Intent;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ListView;
import android.app.Activity;
import android.widget.ArrayAdapter;
import android.widget.ListAdapter;

public class parking extends Activity {

    protected String[] parking = {"Pay and Park Infinit Mall, Andheri East","Baghubai College Parking for Students, Parle West","Railway Station Parking Lane, Next to Trupti Parle West","Lane Opp to Mithibai College Parle West","Satellite Shopping Centre, Jogeshwari","Irla Prime Mall, Vileparle","Mpstme College lane, Vileparle","Costa-Coffee, Vileparle"};
                                                                                                 /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_activity2);
        Intent i=getIntent();
        String pin=i.getStringExtra("PIN");
        ListAdapter adapter;
         adapter= new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, parking);
         ListView parking = (ListView) findViewById(R.id.listView2);
         parking.setAdapter(adapter);

    }



    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_activity2, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
