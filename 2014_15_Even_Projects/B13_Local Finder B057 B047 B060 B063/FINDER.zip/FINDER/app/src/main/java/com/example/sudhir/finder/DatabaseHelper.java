package com.example.sudhir.finder;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {

    public static final String DATABASE_NAME = "parking_places";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
                /*
                 * Create the employee table and populate it with sample data.
                 * In step 6, we will move these hardcoded statements to an XML document.
                 */
        String sql = "CREATE TABLE IF NOT EXISTS parking (" +
                "pin TEXT, " +
                "location TEXT)";
        db.execSQL(sql);

        ContentValues values = new ContentValues();

        values.put("pin", "400060");
        values.put("location", "Satellite Shooping centre Jogeshwaris");
        db.insert("parking", "location", values);

        values.put("pin", "400060");
        values.put("location", "Irla Prime Mall Vileparle");
        db.insert("parking", "pin", values);

        values.put("pin", "400050");
        values.put("location", "Mpstme College lane Vileparle");
        db.insert("parking", "location", values);

        values.put("pin", "400060");
        values.put("location", "Costa-Coffee Vileparle");
        db.insert("parking", "pin", values);

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS parking");
        onCreate(db);
    }

}