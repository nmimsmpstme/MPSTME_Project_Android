Just the important folders included here, the app isnt in a working state. so fr now, u oughtta make d document
for the application, in reference to these folders (refer to them as PACKAGES.). i'll send u d complete gradle build tomm 
after collg. or jst sit wid me and copy d code if need be. (just the xml is left with me)