package com.ciao.xmpp;

import com.ciao.entities.Account;

public interface OnBindListener {
	public void onBind(Account account);
}
