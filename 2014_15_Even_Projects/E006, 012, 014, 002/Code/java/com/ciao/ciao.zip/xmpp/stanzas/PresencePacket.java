package com.ciao.xmpp.stanzas;

public class PresencePacket extends AbstractStanza {

	public PresencePacket() {
		super("presence");
	}
}
