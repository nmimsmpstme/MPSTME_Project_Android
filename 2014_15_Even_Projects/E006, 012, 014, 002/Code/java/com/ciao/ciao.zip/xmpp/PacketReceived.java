package com.ciao.xmpp;

public abstract interface PacketReceived {

}
