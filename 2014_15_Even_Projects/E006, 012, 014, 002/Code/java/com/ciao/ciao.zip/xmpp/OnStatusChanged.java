package com.ciao.xmpp;

import com.ciao.entities.Account;

public interface OnStatusChanged {
	public void onStatusChanged(Account account);
}
