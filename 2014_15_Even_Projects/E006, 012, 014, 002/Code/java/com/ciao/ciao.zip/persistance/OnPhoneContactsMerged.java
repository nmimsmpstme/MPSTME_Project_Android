package com.ciao.persistance;

public interface OnPhoneContactsMerged {
	public void phoneContactsMerged();
}
