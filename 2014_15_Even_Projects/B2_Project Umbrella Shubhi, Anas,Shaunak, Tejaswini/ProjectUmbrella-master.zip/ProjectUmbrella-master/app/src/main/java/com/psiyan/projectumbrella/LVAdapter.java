package com.psiyan.projectumbrella;

import android.app.Activity;
import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * Created by admin on 3/20/2015.
 */
public class LVAdapter extends ArrayAdapter<String>
{
    private Activity context = null;
    private String[] dat = null;
    private String[] sub1= null;
    private String[] sub2= null;

    public LVAdapter(Activity c, String[] data , String[] sub1 , String[] sub2)
    {
        super(c, R.layout.list_item,data);
        this.context= c;
        this.dat = data;
        this.sub1=sub1;
        this.sub2 = sub2;
    }
@Override
    public View getView(int position, View view, ViewGroup parent)
    {
        LayoutInflater inflater = context.getLayoutInflater();
        View rowView= inflater.inflate(R.layout.list_item, null, true);
        TextView Title = (TextView) rowView.findViewById(R.id.tv_title);
        TextView Sub1 = (TextView) rowView.findViewById(R.id.tv_sub1);
        TextView Sub2 = (TextView) rowView.findViewById(R.id.tv_sub2);
        Title.setText(dat[position]);
        Sub1.setText(sub1[position]);
        if(Integer.parseInt(sub2[position]) <=80) {
            Sub2.setText(sub2[position]+"%");
        }
        else
        {
            Sub2.setTextColor(Color.parseColor("#00ff00"));
            Sub2.setText(sub2[position]+"%");
        }
        return rowView;
    }
    }
